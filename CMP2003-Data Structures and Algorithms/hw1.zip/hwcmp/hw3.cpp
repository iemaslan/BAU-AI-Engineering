#include <iostream>
#include <fstream>
#include <unordered_map>
#include <chrono>
#include <vector>
#include <algorithm>

// Function to parse each line of the log file and extract filename
std::string extractFilename(const std::string& line) {
    size_t getPos = line.find("GET");
    if (getPos != std::string::npos) {
        size_t start = line.find_first_of("/", getPos);
        size_t end = line.find_first_of(" ", start);
        if (start != std::string::npos && end != std::string::npos) {
            return line.substr(start, end - start);
        }
    }
    return ""; // If not found or invalid format
}

int main() {
#include <iostream>
#include <vector>

const int TABLE_SIZE = 1000; // Define TABLE_SIZE outside the class

class HashTable {
private:
    struct Node {
        std::string key;
        int value;
        Node* next;

        Node(const std::string& k, int v) : key(k), value(v), next(nullptr) {}
    };

    mutable std::vector<Node*> table; // Mutable to allow modifications in const methods

    int hashFunc(const std::string& key) const {
        int hash = 0;
        for (char c : key) {
            hash = (hash + static_cast<int>(c)) % TABLE_SIZE;
        }
        return hash;
    }

public:
    HashTable() : table(TABLE_SIZE, nullptr) {}

    void insertOrUpdate(const std::string& filename) const {
        int index = hashFunc(filename);

        if (table[index] == nullptr) {
            table[index] = new Node(filename, 1);
        } else {
            Node* current = table[index];
            while (current->next != nullptr && current->key != filename) {
                current = current->next;
            }

            if (current->key == filename) {
                current->value++;
            } else {
                current->next = new Node(filename, 1);
            }
        }
    }

    int getCount(const std::string& filename) const {
        int index = hashFunc(filename);

        Node* current = table[index];
        while (current != nullptr) {
            if (current->key == filename) {
                return current->value;
            }
            current = current->next;
        }

        return 0;
    }

    ~HashTable() {
        for (Node* node : table) {
            while (node != nullptr) {
                Node* temp = node;
                node = node->next;
                delete temp;
            }
        }
    }
};

    // Task 2: Use std::unordered_map
    std::unordered_map<std::string, int> filenameMap;

    // Read log file
    std::ifstream logFile("access_log.txt");
    if (!logFile.is_open()) {
        std::cout << "Error opening file!" << std::endl;
        return 1;
    }

    std::string line;
    while (std::getline(logFile, line)) {
        std::string filename = extractFilename(line);

        // Task 1: Increment count in your hash table
        // hashTable.incrementCount(filename);

        // Task 2: Increment count in std::unordered_map
        filenameMap[filename]++;
    }
    logFile.close();

// Task 3: Compare efficiency
auto start = std::chrono::steady_clock::now();

// Your logic to find top 10 most visited pages goes here
// Use either your hash table or std::unordered_map for this task
// You might use heap data structures or sorting to find top 10

// Example Logic (using filenameMap):
std::vector<std::pair<std::string, int>> sortedFilenames(filenameMap.begin(), filenameMap.end());
std::partial_sort(sortedFilenames.begin(), sortedFilenames.begin() + 10, sortedFilenames.end(),
    [](const std::pair<std::string, int>& a, const std::pair<std::string, int>& b) {
        return a.second > b.second; // Sort by visit count in descending order
    });

// Output the top 10 most visited pages
std::cout << "Filename       # of total visits" << std::endl;
for (int i = 0; i < 10 && i < static_cast<int>(sortedFilenames.size()); ++i) {
    std::cout << sortedFilenames[i].first << "       " << sortedFilenames[i].second << std::endl;
}

auto end = std::chrono::steady_clock::now();
std::chrono::duration<double> elapsedSeconds = end - start;
}